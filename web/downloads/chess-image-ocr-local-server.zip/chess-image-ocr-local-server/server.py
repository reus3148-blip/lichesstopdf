from __future__ import annotations

import os
import sys
import tempfile
import time
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles


PROJECT_ROOT = Path(__file__).parent
PUBLIC_DIR = PROJECT_ROOT / "public"
DEFAULT_OCR_ROOT = Path(r"D:\Workspace\ocr-experiments\2d-chess-ocr")
SIBLING_OCR_ROOT = PROJECT_ROOT.parent / "2d-chess-ocr"
OCR_ROOT = Path(os.environ.get(
    "CHESS_OCR_ROOT",
    str(SIBLING_OCR_ROOT if SIBLING_OCR_ROOT.exists() else DEFAULT_OCR_ROOT),
))
MODEL_PATH = Path(os.environ.get("CHESS_OCR_MODEL", "finetuned-models/yolo26m-finetuned.pt"))
DEVICE = os.environ.get("CHESS_OCR_DEVICE", "cpu")
MAX_IMAGE_BYTES = int(os.environ.get("CHESS_OCR_MAX_IMAGE_BYTES", str(8 * 1024 * 1024)))

if not (OCR_ROOT / "model_inference.py").exists():
    raise RuntimeError(f"2d-chess-ocr repo not found or incomplete: {OCR_ROOT}")

sys.path.insert(0, str(OCR_ROOT))

from model_inference import Chess2DOCRInference  # noqa: E402


def _resolve_model_path() -> Path:
    if MODEL_PATH.is_absolute():
        return MODEL_PATH
    return OCR_ROOT / MODEL_PATH


app = FastAPI(title="Chess Image To FEN")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:8765",
        "http://localhost:8765",
        "https://lab.blundermate.app",
        "http://lab.blundermate.app",
        "null",
    ],
    allow_origin_regex=r"^http://(127\.0\.0\.1|localhost):\d+$",
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory=PUBLIC_DIR), name="static")

engine = Chess2DOCRInference(_resolve_model_path(), device=DEVICE)


@app.get("/")
def index():
    return FileResponse(PUBLIC_DIR / "index.html")


@app.get("/health")
def health() -> dict:
    return {
        "ok": True,
        "ocrRoot": str(OCR_ROOT),
        "model": str(_resolve_model_path()),
        "device": DEVICE,
    }


@app.post("/api/ocr")
async def ocr(file: UploadFile = File(...)) -> dict:
    content_type = file.content_type or ""
    if content_type and not content_type.startswith("image/"):
        raise HTTPException(status_code=415, detail="image file required")

    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="empty image")
    if len(data) > MAX_IMAGE_BYTES:
        raise HTTPException(status_code=413, detail="image too large")

    suffix = Path(file.filename or "image.png").suffix or ".png"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(data)
        tmp_path = Path(tmp.name)

    started = time.perf_counter()
    try:
        results = engine.predict(tmp_path)
        detections, unmatched = engine.to_fen(results)
    finally:
        try:
            tmp_path.unlink(missing_ok=True)
        except OSError:
            pass

    elapsed_ms = round((time.perf_counter() - started) * 1000)
    return {
        "elapsedMs": elapsed_ms,
        "boards": [
            {
                "fen": d.fen,
                "fullFen": f"{d.fen} {d.turn} - - 0 1",
                "turn": d.turn,
                "turnConf": d.turn_conf,
                "orientation": d.orientation,
                "orientationConf": d.orientation_conf,
                "boardConf": d.board_conf,
                "pieceCount": len(d.piece_confs),
                "minPieceConf": min(d.piece_confs.values()) if d.piece_confs else None,
                "pieceConfs": d.piece_confs,
            }
            for d in detections
        ],
        "unmatchedPieces": len(unmatched),
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8765)
