# Chess Image To FEN

Local test app for converting 2D chessboard screenshots into FEN. It exposes
the OCR API that the BlunderMate Lab `/ocr` page calls from the browser.

It uses the cloned `2d-chess-ocr` repo and its local Python environment.

## Prerequisite

Expected OCR repo:

```text
D:\Workspace\ocr-experiments\2d-chess-ocr
```

Portable layout is also supported:

```text
some-folder\
  2d-chess-ocr\
  chess-image-to-fen\
```

The `2d-chess-ocr` repo should already have:

- `.venv`
- `finetuned-models/yolo26m-finetuned.pt`

Upstream OCR repo:

```text
https://github.com/AndrewSpano/2d-chess-ocr
```

## Start

```powershell
.\start.ps1
```

Then open:

```text
http://127.0.0.1:8765
```

Leave this process running while using:

```text
https://lab.blundermate.app/ocr
```

## Override OCR Repo

```powershell
$env:CHESS_OCR_ROOT = 'D:\path\to\2d-chess-ocr'
.\start.ps1
```

## API

```text
GET  /health
POST /api/ocr
```

`POST /api/ocr` expects multipart form data with a `file` image field.

## BlunderMate Lab

The static Lab page at `https://lab.blundermate.app/ocr` can talk to this
local server. Keep this app running at `http://127.0.0.1:8765`, then open the
Lab OCR page from the BlunderMate Lab menu.
