$ErrorActionPreference = 'Stop'

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$OcrRoot = $env:CHESS_OCR_ROOT
if (-not $OcrRoot) {
    $SiblingOcrRoot = Join-Path (Split-Path -Parent $ProjectRoot) '2d-chess-ocr'
    if (Test-Path -LiteralPath $SiblingOcrRoot) {
        $OcrRoot = $SiblingOcrRoot
    } else {
        $OcrRoot = 'D:\Workspace\ocr-experiments\2d-chess-ocr'
    }
}

$Python = Join-Path $OcrRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $Python)) {
    throw "OCR Python venv not found: $Python"
}

$env:CHESS_OCR_ROOT = $OcrRoot
Push-Location $ProjectRoot
try {
    & $Python server.py
} finally {
    Pop-Location
}
